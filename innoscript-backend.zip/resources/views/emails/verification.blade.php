<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification Code</title>
</head>
<body>
<h1>Verification Code</h1>
<p>Dear user,</p>
<p>Your verification code is: {{ $verificationCode }}</p>
<p>Please use this code to verify your account.</p>
<p>Thank you for using our service!</p>
</body>
</html>
